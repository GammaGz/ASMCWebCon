execute unless entity @s[type=minecraft:player] run return 0
data modify storage armskin:work draw set value {pool:[{id:"minecraft:wooden_sword"},{id:"minecraft:stone_sword"},{id:"minecraft:copper_sword"},{id:"minecraft:iron_sword"},{id:"minecraft:golden_sword"},{id:"minecraft:diamond_sword"},{id:"minecraft:netherite_sword"},{id:"minecraft:wooden_spear"},{id:"minecraft:stone_spear"},{id:"minecraft:copper_spear"},{id:"minecraft:iron_spear"},{id:"minecraft:golden_spear"},{id:"minecraft:diamond_spear"},{id:"minecraft:netherite_spear"},{id:"minecraft:bow"}]}
execute store result storage armskin:work draw.index int 1 run random value 0..14
function armskin:pick with storage armskin:work draw
data remove storage armskin:work draw
