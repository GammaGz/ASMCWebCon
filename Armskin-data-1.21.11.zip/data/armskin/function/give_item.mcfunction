$give @s $(id)[minecraft:custom_data={armskin:{pending:1b}}] 1
