$function armskin:give_item with storage armskin:work draw.pool[$(index)]
