$item modify entity @s $(slot) [{function:"minecraft:set_custom_data",tag:{armskin:$(skin)}},{function:"minecraft:set_components",components:{"minecraft:item_model":"$(ns):$(item)"}}]
